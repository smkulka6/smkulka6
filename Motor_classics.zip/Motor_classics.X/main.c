#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/spi1.h"

#define FWD_CMD 0b11101111
#define REV_CMD 0b11101101
#define OFF_CMD 0b11100000
#define MY_ID 'S'

// === SPI motor commands ===
void motor_off(void) {
CS_SetLow(); SPI1_ExchangeByte(OFF_CMD); CS_SetHigh();
}
void motor_forward(void) {
CS_SetLow(); SPI1_ExchangeByte(FWD_CMD); CS_SetHigh();
}
void motor_reverse(void) {
CS_SetLow(); SPI1_ExchangeByte(REV_CMD); CS_SetHigh();
}

// === Send raw UART message ===
void send_uart_message(const char* msg) {
for (uint8_t i = 0; i < 8; i++) {
while (!EUSART1_is_tx_ready());
EUSART1_Write(msg[i]);
}
}

// === Send status message with this subsystem as sender ===
void send_status_to(char receiver, char data) {
char msg[8] = {
'F', 'S',
MY_ID, receiver,
'0', data,
'F', 'S'
};
send_uart_message(msg);
}

// === Broadcast to both K and T (do not modify original msg) ===
void broadcast_status(char data) {
send_status_to('K', data);
send_status_to('T', data);
}

// === Shift bytes into message buffer ===
void shift_and_store(char* buffer, char new_byte) {
for (uint8_t i = 0; i < 7; i++) {
buffer[i] = buffer[i + 1];
}
buffer[7] = new_byte;
}

void main(void)
{
SYSTEM_Initialize();
SPI1_Open(SPI1_DEFAULT);
CS_SetHigh();

DIR_SetLow();
PWM_SetLow();
DIS_SetLow();

__delay_ms(500); // Allow system to settle

char buffer[8] = {0};

while (1)
{
if (EUSART1_is_rx_ready()) {
char byte = EUSART1_Read();
shift_and_store(buffer, byte);

// Check for valid frame
if (buffer[0] == 'F' && buffer[1] == 'S' &&
buffer[6] == 'F' && buffer[7] == 'S') {

char sender = buffer[2];
char receiver = buffer[3];
char type = buffer[4];
char data = buffer[5];

// 1. Drop looped-back messages
if (sender == MY_ID) continue;

// 2. Drop malformed types or data (type ? '0', data not 1/2/3)
if (type != '0' || !(data == '1' || data == '2' || data == '3')) continue;

// 3. Forward unmodified if not for me
if (receiver != MY_ID) {
send_uart_message(buffer); // Forward AS-IS
}

// 4. Process motor command if for me
else {
if (data == '1') {
motor_off();
broadcast_status('1');
} else if (data == '2') {
motor_forward();
broadcast_status('2');
} else if (data == '3') {
motor_reverse();
broadcast_status('3');
}
}

// Clear buffer after processing
for (uint8_t i = 0; i < 8; i++) buffer[i] = 0;
}
}
}
}

